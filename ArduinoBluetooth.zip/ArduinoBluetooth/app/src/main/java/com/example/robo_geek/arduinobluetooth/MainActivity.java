package com.example.robo_geek.arduinobluetooth;

//basic app libraries
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//Bluetooth Adapter represents the phone's bluetooth adapter; the device that lets it operate Bluetooth
import android.bluetooth.BluetoothAdapter;
//Bluetooth Device represents the device we are trying to connect to (in this case the HC-06 Module); an interface
import android.bluetooth.BluetoothDevice;
//Bluetooth socket for communicating with HC-06 Bluetooth module
import android.bluetooth.BluetoothSocket;

//need intent to get permission to use Bluetooth
import android.content.Intent;
//In app notifications;
import android.widget.Toast;
//exception to handle
import java.io.IOException;
//Output stream to HC-06 Module
import java.io.OutputStream;

//import the switch library to interface with the app's switches
import android.widget.CompoundButton;
import android.widget.Switch;

//import the UUID class to use the well known UUID to establish a connection
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    //initialize the bluetooth adapter
    public BluetoothAdapter bluetoothAdapter;

    //initialize the bluetooth device interface
    public BluetoothDevice bluetoothDevice = null;

    //initialize the Bluetooth socket for communication
    public BluetoothSocket bluetoothSocket = null;

    //define the output stream
    public OutputStream output = null;

    //Define the switches
    Switch switch1;
    Switch switch2;
    Switch switch3;
    Switch switch4;
    Switch switch5;
    Switch switch6;
    Switch switch7;
    Switch switch8;


    //This int lets us start the Activity as soon as the return of the notification is 1.
    private static final int BT_ENABLE_REQUEST = 1;

    //Need a UUID to enable server-client connection with the Bluetooth module as a server.
    //Main point off UUID is to be random and big enough so we only have connections with intended target
    //Using the UUID module from Java, we make our UUID (generated online) from a string. The UUID used is "well-known", meaning
    //all HC-06 Modules can identify it
    public static final UUID MY_ID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    //This is the HC-06 Module MAC address, which will let us identify and connect specifically with ours.
    public static final String address = "98:D3:31:F5:14:1C";

    @Override
    //The void onCreate occurs when the program is just created
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switch1 = findViewById(R.id.switch1);
        switch2 = findViewById(R.id.switch2);
        switch3 = findViewById(R.id.switch3);
        switch4 = findViewById(R.id.switch4);
        switch5 = findViewById(R.id.switch5);
        switch6 = findViewById(R.id.switch6);
        switch7 = findViewById(R.id.switch7);
        switch8 = findViewById(R.id.switch8);

        //Set phone's Bluetooth adapter to it's default one
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        //If we do not have Bluetooth enabled, we open a dialog to do so. If the pphone is not supported by Bluetooth, it closes the program
        if (bluetoothAdapter == null) {
            Toast.makeText(getApplicationContext(), "No Bluetooth Adapter available", Toast.LENGTH_LONG);
        } else {if (!bluetoothAdapter.isEnabled()) {
            Intent activate = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(activate, BT_ENABLE_REQUEST);
        } else {
            Toast.makeText(getApplicationContext(), "Bluetooth Enabled", Toast.LENGTH_LONG).show();
        }}

        //We set the interface to the HC-06 by connecting to our mudule specifically with the address
        try{
            bluetoothDevice = bluetoothAdapter.getRemoteDevice(address);
        }
        finally{
            Toast.makeText(getApplicationContext(), "Cannot Connect", Toast.LENGTH_LONG);
        }

        //Create a socket to communicate with the HC-06, otherwise we end the program
        try{
            //Androids and the HC-06 use Radio Frequency Communication, so both of them have to be tuned to the same
            //frequency (in this case 9600 baud or bits per second). Also known as Serial Port Profile
            //The HC-06 acts as the host(server) for the connection, and the phone is the client
            bluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(MY_ID);
        }
        catch (IOException e){
            Toast.makeText(getApplicationContext(), "Error; bluetooth socket not made", Toast.LENGTH_LONG);
            finish();
        }

        //stop discovery of Bluetooth devices; too resource-intensive
        bluetoothAdapter.cancelDiscovery();

        //connect the device to our HC-06 Module, otherwise we end the program
        //the connect() command requires a try and except, otherwise Android Studio comes up with an error
        try{
            bluetoothSocket.connect();
            Toast.makeText(getApplicationContext(), "Connected", Toast.LENGTH_LONG);
        }
        catch(IOException e){
            //if we cannot connect, we close the socket. If we cannot close, shut down the program
            Toast.makeText(getApplicationContext(), "Could not Connect", Toast.LENGTH_LONG);
            try{
                bluetoothSocket.close();
            }
            catch(IOException e2){
                finish();
            }
        }

        //the getOutputStream() command requires a try and except, otherwise Android Studio comes up with an error
        try{
            output = bluetoothSocket.getOutputStream();
        }
        catch (IOException e){
            Toast.makeText(getApplicationContext(), "Could not get output stream", Toast.LENGTH_LONG);
        }


        //create a listener for each switch that listens when the switch is pressed, then if it is in off or on stage we send a message
        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonview, boolean isChecked) {
                if (isChecked){
                    sendData("0");
                }
                else{
                    sendData("1");
                }
            }
        });


        switch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    sendData("2");
                }
                else{
                    sendData("3");
                }
            }
        });

        switch3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton2, boolean b2) {
                if (b2){
                    sendData("4");
                }
                else{
                    sendData("5");
                }
            }
        });

        switch4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton2, boolean b2) {
                if (b2){
                    sendData("6");
                }
                else{
                    sendData("7");
                }
            }
        });

        switch5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton2, boolean b2) {
                if (b2){
                    sendData("8");
                }
                else{
                    sendData("9");
                }
            }
        });

        switch6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton2, boolean b2) {
                if (b2){
                    sendData("a");
                }
                else{
                    sendData("b");
                }
            }
        });

        switch7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton2, boolean b2) {
                if (b2){
                    sendData("c");
                }
                else{
                    sendData("d");
                }
            }
        });

        switch8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton2, boolean b2) {
                if (b2){
                    sendData("e");
                }
                else{
                    sendData("f");
                }
            }
        });


    }

    @Override
    public void onDestroy(){

        try{
            bluetoothSocket.close();
        }
        catch(java.io.IOException e){
            finish();
        }

        try{
            output.close();
        }
        catch(java.io.IOException e){
            finish();
        }

        super.onDestroy();

    }

    public void sendData(String message){
        //convert message to byte form that the output stream can use
        byte[] bytes = message.getBytes();

        try{
            //write our message in byte form to the Bluetooth Socket, which sends it to the HC-06 Module to our Arduino
            output.write(bytes);
        }
        catch(IOException e){
            //Close the program
            Toast.makeText(getApplicationContext(), "Could not send data", Toast.LENGTH_LONG);
            finish();
        }
    }
}
